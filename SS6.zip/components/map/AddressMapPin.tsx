"use client"

/**
 * components/map/AddressMapPin.tsx
 *
 * Shows a small inline Leaflet map for any entity address.
 * Usage:
 *
 *   // On an org profile card:
 *   <AddressMapPin address={org.address} city={org.city} state={org.state} label={org.organizationName} />
 *
 *   // On a vendor card:
 *   <AddressMapPin address={vendor.address} city={vendor.city} state={vendor.state} label={vendor.businessName} type="vendor" />
 */

import { useEffect, useState } from "react"
import { MapPin, Loader2, ExternalLink } from "lucide-react"
import { LeafletMap } from "./LeafletMap"
import { geocodeAddress, LatLng } from "@/lib/geocode"

interface AddressMapPinProps {
  address?: string
  city?: string
  state?: string
  zipCode?: string
  label: string
  type?: "org" | "vendor" | "donor"
  /** Map tile height */
  height?: string
  /** If false, shows only the address text + "View on Map" button */
  showMapInline?: boolean
}

export function AddressMapPin({
  address,
  city,
  state,
  zipCode,
  label,
  type = "org",
  height = "220px",
  showMapInline = true,
}: AddressMapPinProps) {
  const [latlng, setLatlng] = useState<LatLng | null>(null)
  const [loading, setLoading] = useState(false)
  const [failed, setFailed] = useState(false)
  const [expanded, setExpanded] = useState(false)

  const fullAddress = [address, city, state, zipCode].filter(Boolean).join(", ")

  // Build the OpenStreetMap search link (opens in new tab — no API key)
  const osmLink = fullAddress
    ? `https://www.openstreetmap.org/search?query=${encodeURIComponent(fullAddress)}`
    : null

  // Resolve coordinates on mount (or when address changes)
  useEffect(() => {
    if (!fullAddress) return
    setLoading(true)
    setFailed(false)
    geocodeAddress(fullAddress).then((result) => {
      setLatlng(result)
      if (!result) setFailed(true)
      setLoading(false)
    })
  }, [fullAddress])

  return (
    <div className="space-y-2">
      {/* Address text row */}
      <div className="flex items-start gap-2">
        <MapPin className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0">
          <p className="text-sm text-foreground">{fullAddress || "No address provided"}</p>
        </div>
        {osmLink && (
          <a
            href={osmLink}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 flex items-center gap-1 text-xs text-action-blue hover:underline"
          >
            <ExternalLink className="w-3 h-3" />
            Open Map
          </a>
        )}
      </div>

      {/* Inline map tile */}
      {showMapInline && fullAddress && (
        <div>
          {loading && (
            <div
              className="flex items-center justify-center rounded-xl border border-border bg-muted"
              style={{ height }}
            >
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          )}

          {!loading && failed && (
            <div
              className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-muted/40 text-muted-foreground"
              style={{ height }}
            >
              <MapPin className="w-6 h-6 opacity-40" />
              <p className="text-xs">Map unavailable for this address</p>
              {osmLink && (
                <a
                  href={osmLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-action-blue hover:underline flex items-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  Search on OpenStreetMap
                </a>
              )}
            </div>
          )}

          {!loading && latlng && (
            <LeafletMap
              markers={[{ lat: latlng.lat, lng: latlng.lng, label, type }]}
              height={height}
              fitBounds={false}
              zoom={15}
            />
          )}
        </div>
      )}
    </div>
  )
}
