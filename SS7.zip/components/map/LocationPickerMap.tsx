"use client"

/**
 * components/map/LocationPickerMap.tsx
 *
 * Interactive Leaflet map for pinning an exact location.
 * Used in Org settings, Vendor profile, and Donor settings.
 *
 * Fix log:
 *  - addressHint is NO LONGER used to centre the map — it was causing the map
 *    to always show Hyderabad (or whatever city is in the form) even when the
 *    user had not yet pinned anything. The map now starts at the India centre
 *    (or the saved pin) and the user explicitly picks via GPS or click.
 *  - onLocationPicked is called immediately on every pin action (click / drag /
 *    GPS). The parent's Save button is responsible for persisting to Firestore.
 *    The "Confirm Pin" concept is removed — placing the pin IS the action.
 *  - The "Location saved" badge now only appears after the parent calls back
 *    with a non-zero coord that matches what was picked, preventing false positives.
 *  - Drag-end handler is attached once on marker creation and kept stable via ref.
 */

import { useEffect, useRef, useState, useCallback } from "react"
import { Navigation, Loader2, MapPin, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getCurrentLocation, LatLng } from "@/lib/geocode"

interface LocationPickerMapProps {
  /** Pre-saved coordinates from Firestore — map centres here and places pin */
  initialLat?: number
  initialLng?: number
  /**
   * addressHint is intentionally IGNORED for map centring to avoid the
   * "always shows Hyderabad" bug. It is kept in the interface so callers
   * don't need to change their props.
   * @deprecated no-op — do not rely on this for centring
   */
  addressHint?: string
  /** Called immediately whenever the user places / moves the pin */
  onLocationPicked: (coords: LatLng) => void
  height?: string
  className?: string
}

export function LocationPickerMap({
  initialLat,
  initialLng,
  // addressHint intentionally unused — see JSDoc above
  onLocationPicked,
  height = "320px",
  className = "",
}: LocationPickerMapProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<any>(null)
  const markerRef = useRef<any>(null)
  const onPickedRef = useRef(onLocationPicked)
  const initDoneRef = useRef(false)

  // Keep callback ref stable so Leaflet event handlers always call the latest version
  useEffect(() => { onPickedRef.current = onLocationPicked }, [onLocationPicked])

  const hasSavedPin = !!(initialLat && initialLng && initialLat !== 0 && initialLng !== 0)

  const [mapStatus, setMapStatus] = useState<"loading" | "ready">("loading")
  const [pickedLatLng, setPickedLatLng] = useState<LatLng | null>(
    hasSavedPin ? { lat: initialLat!, lng: initialLng! } : null
  )
  const [gpsLoading, setGpsLoading] = useState(false)

  // Place or move the draggable pin
  const placeMarker = useCallback((L: any, map: any, latlng: LatLng) => {
    if (markerRef.current) {
      markerRef.current.setLatLng([latlng.lat, latlng.lng])
    } else {
      const icon = L.divIcon({
        html: `<div style="display:flex;flex-direction:column;align-items:center;filter:drop-shadow(0 2px 8px rgba(0,0,0,0.5));">
          <div style="background:#2563eb;color:white;border-radius:50%;width:38px;height:38px;display:flex;align-items:center;justify-content:center;font-size:20px;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);cursor:grab;">📍</div>
          <div style="width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-top:11px solid #2563eb;margin-top:-2px;"></div>
        </div>`,
        className: "",
        iconSize: [38, 49],
        iconAnchor: [19, 49],
        popupAnchor: [0, -52],
      })
      const marker = L.marker([latlng.lat, latlng.lng], { icon, draggable: true }).addTo(map)
      marker.bindPopup("<b>Your location</b><br>Drag to fine-tune")
      marker.on("dragend", (e: any) => {
        const pos = e.target.getLatLng()
        const coords: LatLng = { lat: pos.lat, lng: pos.lng }
        setPickedLatLng(coords)
        onPickedRef.current(coords)
      })
      markerRef.current = marker
    }
    setPickedLatLng(latlng)
    onPickedRef.current(latlng)
  }, []) // stable — uses ref for callback

  // Initialise map once
  useEffect(() => {
    if (initDoneRef.current) return
    const container = containerRef.current
    if (!container) return
    initDoneRef.current = true

    // Clean up stale Leaflet state from HMR / StrictMode double-invoke
    if ((container as any)._leaflet_id) {
      delete (container as any)._leaflet_id
    }

    import("leaflet").then((L) => {
      if (!containerRef.current || mapRef.current) return

      if (!document.getElementById("leaflet-css")) {
        const link = document.createElement("link")
        link.id = "leaflet-css"
        link.rel = "stylesheet"
        link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        document.head.appendChild(link)
      }

      // Centre: use saved pin if available, otherwise India centre (no addressHint geocode)
      const centre: [number, number] = hasSavedPin
        ? [initialLat!, initialLng!]
        : [20.5937, 78.9629]
      const zoom = hasSavedPin ? 16 : 5

      const map = L.map(containerRef.current!, {
        zoomControl: true,
        attributionControl: true,
      }).setView(centre, zoom)

      mapRef.current = map

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(map)

      // Place pin if we have saved coords
      if (hasSavedPin) {
        placeMarker(L, map, { lat: initialLat!, lng: initialLng! })
      }

      // Click anywhere to place / move pin
      map.on("click", (e: any) => {
        placeMarker(L, map, { lat: e.latlng.lat, lng: e.latlng.lng })
      })

      setMapStatus("ready")
    })

    return () => {
      initDoneRef.current = false
      markerRef.current = null
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
      }
      if (containerRef.current) {
        delete (containerRef.current as any)._leaflet_id
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleUseGPS = async () => {
    setGpsLoading(true)
    try {
      const loc = await getCurrentLocation()
      if (!loc) {
        alert("Could not get your GPS location. Please allow location access in your browser.")
        return
      }
      if (mapRef.current) {
        mapRef.current.setView([loc.lat, loc.lng], 17)
        const L = await import("leaflet")
        placeMarker(L, mapRef.current, loc)
      }
    } finally {
      setGpsLoading(false)
    }
  }

  const handleClear = () => {
    if (markerRef.current) {
      markerRef.current.remove()
      markerRef.current = null
    }
    setPickedLatLng(null)
    onPickedRef.current({ lat: 0, lng: 0 })
  }

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Toolbar */}
      <div className="flex items-center gap-2 flex-wrap">
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={handleUseGPS}
          disabled={gpsLoading || mapStatus === "loading"}
          className="gap-2 rounded-xl"
        >
          {gpsLoading
            ? <Loader2 className="w-4 h-4 animate-spin" />
            : <Navigation className="w-4 h-4" />}
          {gpsLoading ? "Getting GPS…" : "Use My Location"}
        </Button>

        {pickedLatLng && (
          <Button
            type="button"
            size="sm"
            variant="ghost"
            onClick={handleClear}
            className="gap-2 rounded-xl text-muted-foreground"
          >
            <RotateCcw className="w-4 h-4" />
            Clear Pin
          </Button>
        )}

        {pickedLatLng && (
          <span className="text-xs text-green-700 bg-green-50 border border-green-200 px-2.5 py-1 rounded-full font-medium">
            📍 {pickedLatLng.lat.toFixed(5)}, {pickedLatLng.lng.toFixed(5)}
          </span>
        )}
      </div>

      {/* Map */}
      <div className="relative">
        <div
          ref={containerRef}
          style={{ height, width: "100%" }}
          className={`rounded-xl overflow-hidden border-2 transition-colors ${
            pickedLatLng ? "border-blue-400" : "border-border"
          }`}
        />
        {mapStatus === "loading" && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/70 rounded-xl">
            <div className="text-center text-muted-foreground">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
              <p className="text-xs">Loading map…</p>
            </div>
          </div>
        )}
      </div>

      {/* Hint */}
      <p className="text-xs text-muted-foreground flex items-center gap-1">
        <MapPin className="w-3 h-3 shrink-0" />
        {pickedLatLng
          ? "Location pinned — hit Save to persist to your profile."
          : "Click anywhere on the map, or use "Use My Location" to pin your exact spot. Then hit Save."}
      </p>
    </div>
  )
}