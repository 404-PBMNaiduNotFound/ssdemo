"use client"

import { useEffect, useRef } from "react"

export type MarkerType = "org" | "vendor" | "donor" | "user"

export interface MapMarker {
  lat: number
  lng: number
  label: string
  sublabel?: string
  type?: MarkerType
  onClick?: () => void
}

interface LeafletMapProps {
  markers: MapMarker[]
  userLocation?: { lat: number; lng: number } | null
  height?: string
  className?: string
  fitBounds?: boolean
  zoom?: number
}

const MARKER_COLORS: Record<MarkerType, string> = {
  org: "#2563eb",
  vendor: "#ea580c",
  donor: "#16a34a",
  user: "#7c3aed",
}

const MARKER_LABELS: Record<MarkerType, string> = {
  org: "🏢",
  vendor: "🛒",
  donor: "❤️",
  user: "📍",
}

function makeDivIcon(L: any, type: MarkerType = "org") {
  const color = MARKER_COLORS[type]
  const emoji = MARKER_LABELS[type]
  return L.divIcon({
    html: `
      <div style="display:flex;flex-direction:column;align-items:center;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.3));">
        <div style="background:${color};color:white;border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;font-size:16px;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.25);">${emoji}</div>
        <div style="width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:8px solid ${color};margin-top:-1px;"></div>
      </div>`,
    className: "",
    iconSize: [32, 40],
    iconAnchor: [16, 40],
    popupAnchor: [0, -42],
  })
}

export function LeafletMap({
  markers,
  userLocation,
  height = "400px",
  className = "",
  fitBounds = true,
  zoom = 13,
}: LeafletMapProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<any>(null)
  // Tracks whether the async init has already started (survives StrictMode double-invoke)
  const initStartedRef = useRef(false)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    // StrictMode fix: if a map is already attached to this DOM node, tear it down first
    // before creating a new one. Leaflet stores the instance on the element itself.
    if ((container as any)._leaflet_id) {
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
      }
      // Leaflet doesn't always clean this internal id on .remove() — force it
      delete (container as any)._leaflet_id
    }

    // Prevent double-init within the same effect lifecycle
    if (initStartedRef.current) return
    initStartedRef.current = true

    import("leaflet").then((L) => {
      // Safety: container may have unmounted while the import was in flight
      if (!containerRef.current) return
      // If another StrictMode cycle already created a map, bail out
      if (mapRef.current) return

      // Inject Leaflet CSS once
      if (!document.getElementById("leaflet-css")) {
        const link = document.createElement("link")
        link.id = "leaflet-css"
        link.rel = "stylesheet"
        link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        document.head.appendChild(link)
      }

      const centre: [number, number] = userLocation
        ? [userLocation.lat, userLocation.lng]
        : markers[0]
        ? [markers[0].lat, markers[0].lng]
        : [20.5937, 78.9629]

      const map = L.map(containerRef.current!, { zoomControl: true }).setView(centre, zoom)
      mapRef.current = map

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(map)

      const allPoints: [number, number][] = []

      if (userLocation) {
        allPoints.push([userLocation.lat, userLocation.lng])
        L.marker([userLocation.lat, userLocation.lng], { icon: makeDivIcon(L, "user") })
          .addTo(map)
          .bindPopup("<b>📍 Your Location</b>")
      }

      markers.forEach((m) => {
        allPoints.push([m.lat, m.lng])
        const marker = L.marker([m.lat, m.lng], { icon: makeDivIcon(L, m.type ?? "org") }).addTo(map)
        marker.bindPopup(`
          <div style="min-width:160px;font-family:sans-serif;">
            <b style="font-size:14px;">${m.label}</b>
            ${m.sublabel ? `<p style="margin:4px 0 0;font-size:12px;color:#666;">${m.sublabel}</p>` : ""}
          </div>`)
        if (m.onClick) marker.on("click", () => m.onClick!())
      })

      if (fitBounds && allPoints.length > 1) {
        map.fitBounds(allPoints, { padding: [40, 40] })
      }
    })

    return () => {
      initStartedRef.current = false
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
      }
      // Also clear the Leaflet internal id so the next mount starts clean
      if (containerRef.current) {
        delete (containerRef.current as any)._leaflet_id
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div
      ref={containerRef}
      style={{ height, width: "100%" }}
      className={`rounded-xl overflow-hidden border border-border ${className}`}
    />
  )
}
