"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { getDonorOrders } from "@/lib/firestore"
import { TransactionsList } from "@/components/transactions/transactions-list"
import { Loader2 } from "lucide-react"

export default function DonorTransactionsPage() {
  const { user, userDoc } = useAuth()
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    const loadTransactions = async () => {
      setLoading(true)
      try {
        const orders = await getDonorOrders(user.uid)
        setTransactions(orders)
      } catch (error) {
        console.error("Failed to load transactions:", error)
      } finally {
        setLoading(false)
      }
    }

    loadTransactions()
  }, [user])

  if (!user || userDoc?.role !== "donor") {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-muted-foreground">Access denied. Donor role required.</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-navy-primary mb-2">My Transactions</h1>
        <p className="text-muted-foreground">
          View all your vendor purchases and donation payments
        </p>
      </div>

      <TransactionsList
        transactions={transactions}
        loading={loading}
        userRole="donor"
      />
    </div>
  )
}
