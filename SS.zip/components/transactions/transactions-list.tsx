"use client"

import { useState } from "react"
import { OrderDoc } from "@/lib/firestore"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronDown, Package, Clock, CheckCircle, Truck } from "lucide-react"
import { formatFirestoreDate } from "@/lib/utils"

interface TransactionsListProps {
  transactions: OrderDoc[]
  loading: boolean
  userRole: "donor" | "organization" | "vendor"
}

const STATUS_CONFIG: Record<string, { color: string; icon: React.ReactNode; label: string }> = {
  payment_confirmed: {
    color: "bg-blue-100 text-blue-700 border-blue-300",
    icon: <CheckCircle className="w-4 h-4" />,
    label: "Payment Confirmed",
  },
  preparing: {
    color: "bg-yellow-100 text-yellow-700 border-yellow-300",
    icon: <Clock className="w-4 h-4" />,
    label: "Preparing",
  },
  ready_for_pickup: {
    color: "bg-purple-100 text-purple-700 border-purple-300",
    icon: <Package className="w-4 h-4" />,
    label: "Ready for Pickup",
  },
  picked_up: {
    color: "bg-green-100 text-success-green border-green-300",
    icon: <Truck className="w-4 h-4" />,
    label: "Picked Up",
  },
}

type FilterStatus = "all" | "payment_confirmed" | "preparing" | "ready_for_pickup" | "picked_up"

export function TransactionsList({ transactions, loading, userRole }: TransactionsListProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all")

  const filteredTransactions =
    filterStatus === "all"
      ? transactions
      : transactions.filter((t) => t.status === filterStatus)

  if (loading) {
    return (
      <Card className="p-8">
        <div className="text-center">
          <p className="text-muted-foreground">Loading transactions...</p>
        </div>
      </Card>
    )
  }

  if (transactions.length === 0) {
    return (
      <Card className="p-8">
        <div className="text-center">
          <Package className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground">No transactions yet</p>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Filter Tabs */}
      <div className="flex gap-2 flex-wrap">
        <Button
          size="sm"
          variant={filterStatus === "all" ? "default" : "outline"}
          onClick={() => setFilterStatus("all")}
          className={filterStatus === "all" ? "bg-navy-primary" : ""}
        >
          All ({transactions.length})
        </Button>
        {Object.entries(STATUS_CONFIG).map(([key, config]) => {
          const count = transactions.filter((t) => t.status === key).length
          return (
            <Button
              key={key}
              size="sm"
              variant={filterStatus === key ? "default" : "outline"}
              onClick={() => setFilterStatus(key as FilterStatus)}
              className={filterStatus === key ? "bg-navy-primary" : ""}
            >
              {config.label} ({count})
            </Button>
          )
        })}
      </div>

      {/* Transactions */}
      <div className="space-y-3">
        {filteredTransactions.map((transaction) => {
          const statusConfig = STATUS_CONFIG[transaction.status]
          const isExpanded = expandedId === transaction.id

          return (
            <Card
              key={transaction.id}
              className="overflow-hidden hover:shadow-md transition-shadow"
            >
              <button
                onClick={() =>
                  setExpandedId(isExpanded ? null : transaction.id || "")
                }
                className="w-full text-left p-4 hover:bg-muted/50 transition-colors flex items-center justify-between"
              >
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${statusConfig.color}`}>
                      {statusConfig.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-navy-primary">
                        Order #{transaction.orderId}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {formatFirestoreDate(transaction.orderDate)}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm pt-2">
                    {userRole === "donor" && (
                      <>
                        <div>
                          <p className="text-muted-foreground">Vendor</p>
                          <p className="font-medium">{transaction.vendorName}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Organization</p>
                          <p className="font-medium">
                            {transaction.organizationName}
                          </p>
                        </div>
                      </>
                    )}
                    {userRole === "organization" && (
                      <>
                        <div>
                          <p className="text-muted-foreground">Donor</p>
                          <p className="font-medium">{transaction.donorName}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Vendor</p>
                          <p className="font-medium">{transaction.vendorName}</p>
                        </div>
                      </>
                    )}
                    {userRole === "vendor" && (
                      <>
                        <div>
                          <p className="text-muted-foreground">Donor</p>
                          <p className="font-medium">{transaction.donorName}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Organization</p>
                          <p className="font-medium">
                            {transaction.organizationName}
                          </p>
                        </div>
                      </>
                    )}

                    <div>
                      <p className="text-muted-foreground">Status</p>
                      <p className={`font-medium inline-block px-2 py-1 rounded text-xs ${statusConfig.color}`}>
                        {statusConfig.label}
                      </p>
                    </div>

                    <div>
                      <p className="text-muted-foreground">Amount</p>
                      <p className="font-bold text-success-green">
                        ₹{transaction.amount.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>

                <ChevronDown
                  className={`w-5 h-5 transition-transform ${
                    isExpanded ? "rotate-180" : ""
                  } text-muted-foreground`}
                />
              </button>

              {/* Expanded Details */}
              {isExpanded && (
                <div className="border-t border-border bg-muted/30 p-4 space-y-4">
                  <div>
                    <h4 className="font-semibold text-navy-primary mb-3">
                      Items
                    </h4>
                    <div className="space-y-2">
                      {transaction.items.map((item, idx) => (
                        <div
                          key={idx}
                          className="flex justify-between text-sm p-2 bg-background rounded"
                        >
                          <span>{item.name}</span>
                          <span className="text-muted-foreground">
                            {item.quantity} × ₹{item.price} = ₹
                            {(item.quantity * item.price).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border-t border-border pt-4">
                    <h4 className="font-semibold text-navy-primary mb-3">
                      Delivery Address
                    </h4>
                    <div className="text-sm space-y-1 bg-background p-3 rounded">
                      <p className="font-medium">{transaction.receiverName}</p>
                      <p className="text-muted-foreground">
                        {transaction.receiverPhone}
                      </p>
                      <p className="text-muted-foreground">
                        {transaction.receiverAddress}
                      </p>
                    </div>
                  </div>

                  {transaction.notes && (
                    <div className="border-t border-border pt-4">
                      <h4 className="font-semibold text-navy-primary mb-2">
                        Notes
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {transaction.notes}
                      </p>
                    </div>
                  )}

                  <div className="border-t border-border pt-4 flex justify-between items-center">
                    <div>
                      <p className="text-xs text-muted-foreground">Total Amount</p>
                      <p className="text-lg font-bold text-vendor-orange">
                        ₹{transaction.amount.toFixed(2)}
                      </p>
                    </div>
                    <Button size="sm" variant="outline">
                      View Details
                    </Button>
                  </div>
                </div>
              )}
            </Card>
          )
        })}

        {filteredTransactions.length === 0 && (
          <Card className="p-8">
            <div className="text-center">
              <p className="text-muted-foreground">
                No transactions with status "{filterStatus}"
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
