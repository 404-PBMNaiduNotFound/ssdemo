// lib/sanitize.ts
// Utility: strip undefined values before any Firestore write.
// Firestore throws if you pass `undefined` as a field value.

/**
 * Recursively removes all keys whose value is `undefined` from a plain object.
 * Returns a `Record<string, unknown>` so Firestore's `updateDoc` / `setDoc`
 * overloads (which expect `UpdateData<T>`) accept the result without an extra cast.
 * Arrays are returned as-is (Firestore handles array members separately).
 */
export function sanitizeData(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(obj)) {
    if (value === undefined) continue
    if (
      value !== null &&
      typeof value === "object" &&
      !Array.isArray(value) &&
      !(value instanceof Date)
    ) {
      const nested = sanitizeData(value as Record<string, unknown>)
      if (Object.keys(nested).length > 0) {
        result[key] = nested
      }
    } else {
      result[key] = value
    }
  }
  return result
}
